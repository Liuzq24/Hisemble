import os
import numpy as np
import scipy.sparse as sp
from scipy.sparse import csr_matrix
import scanpy as sc
import igraph as ig
import leidenalg
from sklearn.metrics.pairwise import rbf_kernel, cosine_similarity
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
import warnings
import tensorflow as tf

from STAGATE.utils import Cal_Spatial_Net
from STAGATE.STAGATE.Train_STAGATE import train_STAGATE

tf.compat.v1.disable_eager_execution()
warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
# ==========================================
# 1. 图构建与 Hisemble 融合核心函数
# ==========================================
def build_knn_graph_chunked_cpu(embedding: np.ndarray, k_neighbors: int, metric: str, chunk_size: int = 2048, random_seed=42) -> csr_matrix:
    n_samples = embedding.shape[0]
    all_rows, all_cols, all_data = [], [], []
    gamma = 1.0 / (embedding.shape[1] * embedding.var() + 1e-12) if metric == 'gaussian' else None

    for i in range(0, n_samples, chunk_size):
        end_idx = min(i + chunk_size, n_samples)
        chunk_embedding = embedding[i:end_idx]
        
        if metric == 'gaussian':
            sim_chunk = rbf_kernel(chunk_embedding, embedding, gamma=gamma)
        else: 
            sim_chunk = np.maximum(cosine_similarity(chunk_embedding, embedding), 0)

        np.random.seed(random_seed) 
        indices_chunk = np.argsort(-sim_chunk, axis=1)[:, 1:k_neighbors + 1]
        data_chunk = np.take_along_axis(sim_chunk, indices_chunk, axis=1)
        rows_chunk = np.repeat(np.arange(i, end_idx), k_neighbors)
        
        all_rows.append(rows_chunk)
        all_cols.append(indices_chunk.flatten())
        all_data.append(data_chunk.flatten())
        
    W_sparse = csr_matrix((np.concatenate(all_data), (np.concatenate(all_rows), np.concatenate(all_cols))), shape=(n_samples, n_samples))
    return (W_sparse + W_sparse.T) / 2

def normalize_sparse(W_sparse: csr_matrix) -> csr_matrix:
    row_sums = W_sparse.sum(axis=1).A.flatten()
    inv_denominators = 1.0 / np.where(row_sums == 0, 1e-9, 2.0 * row_sums)
    return (sp.diags(inv_denominators) @ W_sparse + sp.diags(np.full(W_sparse.shape[0], 0.5))).tocsr()

def sparsify_matrix(sparse_matrix: csr_matrix, k_neighbors: int) -> csr_matrix:
    n_samples = sparse_matrix.shape[0]
    all_rows, all_cols, all_data = [], [], []
    for i in range(n_samples):
        row_slice = sparse_matrix.getrow(i)
        if row_slice.nnz > k_neighbors:
            top_k_idx = np.argpartition(-row_slice.data, k_neighbors)[:k_neighbors]
            all_rows.append(np.full(k_neighbors, i, dtype=np.int32))
            all_cols.append(row_slice.indices[top_k_idx])
            all_data.append(row_slice.data[top_k_idx])
        else:
            all_rows.append(np.full(row_slice.nnz, i, dtype=np.int32))
            all_cols.append(row_slice.indices)
            all_data.append(row_slice.data)
    return csr_matrix((np.concatenate(all_data), (np.concatenate(all_rows), np.concatenate(all_cols))), shape=(n_samples, n_samples))

def Hisemble(W_list: list, k_neighbors: int = 20, n_iterations: int = 20) -> csr_matrix:
    num_views = len(W_list)
    P_list = [normalize_sparse(W) for W in W_list]
    k_retained = k_neighbors * 2
    for _ in range(n_iterations):
        P_updated_list = []
        for i in range(num_views):
            avg_P_others = sum(P_list[j] for j in range(num_views) if i != j) / (num_views - 1)
            P_updated = normalize_sparse(sparsify_matrix(W_list[i] @ avg_P_others @ W_list[i].T, k_retained))
            P_updated_list.append(P_updated)
        P_list = P_updated_list
    final_P = sum(P_list) / num_views
    return (final_P + final_P.T) / 2

# ==========================================
# 2. 聚类搜索函数 (二分查找最佳分辨率)
# ==========================================
def find_best_matrix(matrix, true_cell_types, low=0.1, high=5.0, tolerance=0.01, seed=42):
    sources, targets = matrix.nonzero()
    g = ig.Graph(list(zip(sources, targets)), directed=False)
    g.es['weight'] = matrix[sources, targets].A1

    def get_n_clusters(res):
        partition = leidenalg.find_partition(g, leidenalg.RBConfigurationVertexPartition, 
                                             weights=g.es['weight'], resolution_parameter=res, seed=seed)
        return len(np.unique(partition.membership)), partition.membership

    best_membership = None
    best_resolution = (low + high) / 2

    while high - low > tolerance:
        mid = (low + high) / 2
        n_clusters, membership = get_n_clusters(mid)
        if n_clusters < true_cell_types:
            low = mid
        elif n_clusters > true_cell_types:
            high = mid
        else:
            best_membership = membership
            break
            
    if best_membership is None:
        _, best_membership = get_n_clusters((low + high) / 2)
        
    return np.array(best_membership).astype(str)

# ==========================================
# 3. 核心单文件处理逻辑
# ==========================================
def process_single_file(filename, data_dir, k_neighbors=20, k_spatial=8, n_iterations=20, seed=42):
    tf.random.set_seed(seed)
    np.random.seed(seed)
    
    file_path = os.path.join(data_dir, filename)
    adata = sc.read_h5ad(file_path)
    prefix = filename.split('_expr')[0]
    
    # 提取空间坐标
    if 'array_col' in adata.obs.columns:
        X_spatial = adata.obs[['array_col', 'array_row']].values
    else:
        X_spatial = adata.obs[['x', 'y']].values
    adata.obsm['spatial'] = X_spatial
    
    true_labels = adata.obs['Annotation_for_Combined'].values
    n_true_clusters = len(np.unique(true_labels))

    # --- 获取 3 种 Embedding ---
    print(f"[{prefix}] 1. Extracting PCA Embedding...")
    sc.pp.highly_variable_genes(adata, flavor="seurat_v3", n_top_genes=3000)
    sc.tl.pca(adata, n_comps=30, random_state=seed)
    X_pca = adata.obsm['X_pca']

    print(f"[{prefix}] 2. Training STAGATE...")
    Cal_Spatial_Net(adata, k_cutoff=k_spatial, model='KNN')
    adata = train_STAGATE(adata, alpha=0, random_seed=seed)
    X_stagate = adata.obsm['STAGATE']

    # --- 构图与融合 ---
    print(f"[{prefix}] 3. Constructing Graphs & Running Hisemble...")
    P_pca = build_knn_graph_chunked_cpu(X_pca, k_neighbors, metric='cosine', random_seed=seed)
    P_stagate = build_knn_graph_chunked_cpu(X_stagate, k_neighbors, metric='cosine', random_seed=seed)
    P_spatial = build_knn_graph_chunked_cpu(X_spatial, k_spatial, metric='gaussian', random_seed=seed)
    
    W_fused = Hisemble([P_spatial, P_pca, P_stagate], k_neighbors=k_neighbors, n_iterations=n_iterations)

    # --- 聚类与指标计算 ---
    print(f"[{prefix}] 4. Clustering & Evaluating...")
    labels_stagate = find_best_matrix(P_stagate, n_true_clusters, seed=seed)
    labels_hisemble = find_best_matrix(W_fused, n_true_clusters, seed=seed)
    
    res = {
        "STAGATE_ARI": adjusted_rand_score(true_labels, labels_stagate),
        "STAGATE_NMI": normalized_mutual_info_score(true_labels, labels_stagate),
        "Hisemble_ARI": adjusted_rand_score(true_labels, labels_hisemble),
        "Hisemble_NMI": normalized_mutual_info_score(true_labels, labels_hisemble)
    }
    
    print(f"✅ {prefix} Done | STAGATE [ARI:{res['STAGATE_ARI']:.4f} NMI:{res['STAGATE_NMI']:.4f}] | Hisemble [ARI:{res['Hisemble_ARI']:.4f} NMI:{res['Hisemble_NMI']:.4f}]\n")
    return res

# ==========================================
# 4. 批量运行主程序
# ==========================================
if __name__ == "__main__":
    DATA_DIR = "__HISEMBLE_SPATIAL_ROOT__"
    FILE_LIST = [
        "E11_0-S1_expr_preprocessed.h5ad",
        "E13_5-S1_expr_preprocessed.h5ad",
        "E15_5-S1_expr_preprocessed.h5ad",
        "E18_5-S1_expr_preprocessed.h5ad"
    ]
    
    final_results = {}
    
    print("🚀 开始批量处理空间转录组数据...\n" + "="*50)
    for file in FILE_LIST:
        if not os.path.exists(os.path.join(DATA_DIR, file)):
            print(f"❌ 警告: 文件未找到 {file}")
            continue
        final_results[file.split('_expr')[0]] = process_single_file(filename=file, data_dir=DATA_DIR)
        
    # --- 打印汇总表格 ---
    print("\n" + "="*60)
    print("🎉 BATCH PROCESSING SUMMARY 🎉")
    print(f"{'Sample':<12} | {'STAGATE_ARI':<12} | {'STAGATE_NMI':<12} | {'Hisem_ARI':<10} | {'Hisem_NMI':<10}")
    print("-" * 60)
    for sample, met in final_results.items():
        print(f"{sample:<12} | {met['STAGATE_ARI']:<12.4f} | {met['STAGATE_NMI']:<12.4f} | {met['Hisemble_ARI']:<10.4f} | {met['Hisemble_NMI']:<10.4f}")
    print("="*60)