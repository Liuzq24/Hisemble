import pandas as pd
import numpy as np
import scipy.sparse as sp
from scipy.sparse import csr_matrix
import scanpy as sc
import matplotlib as mpl
mpl.use('Agg') # 在服务器批量跑图时，使用 Agg 后端避免 GUI 报错
from matplotlib import pyplot as plt
from matplotlib import font_manager
import os
import random
import igraph as ig
import leidenalg
from sklearn.metrics.pairwise import rbf_kernel, cosine_similarity
import warnings
import tensorflow as tf

from STAGATE.utils import Cal_Spatial_Net
from STAGATE.STAGATE.Train_STAGATE import train_STAGATE

# 忽略警告并限制 TF 输出
tf.compat.v1.disable_eager_execution()
warnings.filterwarnings("ignore")
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

font_dir = "../"
arial_regular_path = os.path.join(font_dir, "Arial.ttf")
arial_bold_path = os.path.join(font_dir, "Arial Bold.ttf")

if os.path.exists(arial_regular_path):
    font_manager.fontManager.addfont(arial_regular_path)
else:
    print(f"⚠️ 警告: 找不到常规字体文件 {arial_regular_path}")

if os.path.exists(arial_bold_path):
    font_manager.fontManager.addfont(arial_bold_path)
else:
    print(f"⚠️ 警告: 找不到加粗字体文件 {arial_bold_path}")

plt.rcParams['font.family'] = 'Arial'
mpl.rcParams['pdf.fonttype'] = 42 
mpl.rcParams['ps.fonttype'] = 42
plt.rcParams['axes.linewidth'] = 0.8
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'

# ==============================================================================
# 1. 配置路径与参数
# ==============================================================================
# 指向本地解压的 10x Visium 文件夹
DATA_DIR = "./V1_Breast_Cancer_Block_A_Section_1"

K_NEIGHBORS_RNA = 20    
K_NEIGHBORS_SPATIAL = 6 # 针对 Visium 六边形网格，一般设为 6
N_ITERATIONS = 20   
SEED = 42           
RESOLUTION = 0.6    # 使用固定分辨率

def set_global_seed(seed=42):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)

# ==============================================================================
# 2. Hisemble 核心图学习与聚类算法
# ==============================================================================
def build_knn_graph_chunked_cpu(embedding: np.ndarray, k_neighbors: int, metric: str, chunk_size: int = 2048, random_seed=42) -> csr_matrix:
    n_samples = embedding.shape[0]
    all_rows, all_cols, all_data = [], [], []
    gamma = 1.0 / (embedding.shape[1] * embedding.var() + 1e-12) if metric == 'gaussian' else None

    for i in range(0, n_samples, chunk_size):
        start_idx = i
        end_idx = min(i + chunk_size, n_samples)
        chunk_embedding = embedding[start_idx:end_idx]
        if metric == 'gaussian':
            sim_chunk = rbf_kernel(chunk_embedding, embedding, gamma=gamma)
        elif metric == 'cosine':
            sim_chunk = np.maximum(cosine_similarity(chunk_embedding, embedding), 0)

        np.random.seed(random_seed) 
        indices_chunk = np.argsort(-sim_chunk, axis=1)[:, 1:k_neighbors + 1]
        data_chunk = np.take_along_axis(sim_chunk, indices_chunk, axis=1)
        rows_chunk = np.repeat(np.arange(start_idx, end_idx), k_neighbors)
        
        all_rows.append(rows_chunk)
        all_cols.append(indices_chunk.flatten())
        all_data.append(data_chunk.flatten())
        
    final_rows = np.concatenate(all_rows)
    final_cols = np.concatenate(all_cols)
    final_data = np.concatenate(all_data)
    W_sparse = csr_matrix((final_data, (final_rows, final_cols)), shape=(n_samples, n_samples))
    return (W_sparse + W_sparse.T) / 2

def normalize_sparse(W_sparse: csr_matrix) -> csr_matrix:
    row_sums = W_sparse.sum(axis=1).A.flatten()
    inv_denominators = 1.0 / np.where(row_sums == 0, 1e-9, 2.0 * row_sums)
    P_non_diag = sp.diags(inv_denominators) @ W_sparse
    return (P_non_diag + sp.diags(np.full(W_sparse.shape[0], 0.5))).tocsr()

def sparsify_matrix(sparse_matrix: csr_matrix, k_neighbors: int) -> csr_matrix:
    n_samples = sparse_matrix.shape[0]
    all_rows, all_cols, all_data = [], [], []
    for i in range(n_samples):
        row_slice = sparse_matrix.getrow(i)
        if row_slice.nnz > k_neighbors:
            top_k_idx = np.argpartition(-row_slice.data, k_neighbors)[:k_neighbors]
            all_rows.append(np.full(k_neighbors, i, dtype=np.int32))
            all_cols.append(row_slice.indices[top_k_idx])
            all_data.append(row_slice.data[top_k_idx])
        else:
            all_rows.append(np.full(row_slice.nnz, i, dtype=np.int32))
            all_cols.append(row_slice.indices)
            all_data.append(row_slice.data)
    return csr_matrix((np.concatenate(all_data), (np.concatenate(all_rows), np.concatenate(all_cols))), shape=(n_samples, n_samples))

def Hisemble(W_list: list, k_neighbors: int = 15, n_iterations: int = 20) -> csr_matrix:
    num_views = len(W_list)
    n_samples = W_list[0].shape[0]
    P_list = [normalize_sparse(W) for W in W_list]
    k_retained = k_neighbors * 2
    for _ in range(n_iterations):
        P_updated_list = []
        for i in range(num_views):
            avg_P_others = sum(P_list[j] for j in range(num_views) if i != j) / (num_views - 1)
            P_updated = normalize_sparse(sparsify_matrix(W_list[i] @ avg_P_others @ W_list[i].T, k_retained))
            P_updated_list.append(P_updated)
        P_list = P_updated_list
    final_P = sum(P_list) / num_views
    return (final_P + final_P.T) / 2

def get_leiden_labels(affinity_matrix, resolution=0.6, seed=42):
    sources, targets = affinity_matrix.nonzero()
    weights = affinity_matrix[sources, targets].A1
    g = ig.Graph(list(zip(sources, targets)), directed=False)
    g.es['weight'] = weights
    
    partition = leidenalg.find_partition(
        g, leidenalg.RBConfigurationVertexPartition, 
        weights=g.es['weight'], resolution_parameter=resolution, seed=seed
    )
    return np.array(partition.membership)

def format_labels(labels_array):
    """将聚类结果转为从 1 开始的字符串，并按数值大小定义为有序 Categorical"""
    labels_int = labels_array.astype(int) + 1
    cats_str = [str(x) for x in sorted(np.unique(labels_int))]
    return pd.Categorical(labels_int.astype(str), categories=cats_str, ordered=True)

# ==============================================================================
# 3. 数据加载与处理流水线
# ==============================================================================
def main():
    set_global_seed(SEED)
    print(f"\n{'='*60}")
    print(f"🚀 开始加载 10x Visium 数据: {DATA_DIR}")
    print(f"{'='*60}")
    
    # 从本地文件夹加载
    adata = sc.read_visium(DATA_DIR)
    adata.var_names_make_unique()
    print(f"Data shape: {adata.shape}")
    
    # 提取空间坐标 (View 3)
    embedding_spatial = adata.obsm['spatial']
    
    print(">>> 1. 预处理 RNA 数据并执行 PCA (View 1)...")
    sc.pp.calculate_qc_metrics(adata, inplace=True)
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    sc.pp.highly_variable_genes(adata, flavor="seurat", n_top_genes=2000)
    sc.pp.pca(adata)
    embedding_rna = adata.obsm['X_pca']
    
    print(">>> 2. 训练 STAGATE 获取深度空间特征 (View 2)...")
    # 构建 STAGATE 空间图，此处使用 KNN 模式（推荐 k=6 用于 Visium）
    Cal_Spatial_Net(adata, k_cutoff=K_NEIGHBORS_SPATIAL, model='KNN')
    # 训练模型获取 STAGATE embedding
    adata = train_STAGATE(adata, alpha=0, random_seed=SEED)
    embedding_stagate = adata.obsm['STAGATE']
    
    print(">>> 3. 构建邻接图与三模态融合计算 (Hisemble)...")
    # 分别构建三模态的邻接矩阵
    W_rna = build_knn_graph_chunked_cpu(embedding_rna, k_neighbors=K_NEIGHBORS_RNA, metric='gaussian', random_seed=SEED)
    W_stagate = build_knn_graph_chunked_cpu(embedding_stagate, k_neighbors=K_NEIGHBORS_RNA, metric='cosine', random_seed=SEED)
    W_spatial = build_knn_graph_chunked_cpu(embedding_spatial, k_neighbors=K_NEIGHBORS_SPATIAL, metric='gaussian', random_seed=SEED)
    
    # 将 RNA, STAGATE, 空间坐标融合
    W_fused = Hisemble([W_rna, W_stagate, W_spatial], k_neighbors=15, n_iterations=N_ITERATIONS)
    
    print(f">>> 4. 执行 Leiden 聚类 (Resolution={RESOLUTION})...")
    # 我们只对主要的三个视角进行聚类用于可视化对比
    labels_rna = get_leiden_labels(W_rna, resolution=RESOLUTION, seed=SEED)
    labels_stagate = get_leiden_labels(W_stagate, resolution=RESOLUTION, seed=SEED)
    labels_hisemble = get_leiden_labels(W_fused, resolution=RESOLUTION, seed=SEED)
    
    # 格式化聚类标签：+1 且数值排序
    adata.obs['Cluster_RNA'] = format_labels(labels_rna)
    adata.obs['Cluster_STAGATE'] = format_labels(labels_stagate)
    adata.obs['Cluster_Hisemble'] = format_labels(labels_hisemble)
    
    # ==============================================================================
    # 4. 绘图：1x4 大横版 (完美适配 A4) + 底部独立图例
    # ==============================================================================
    print(">>> 5. 正在生成排版大图...")
    # 画布比例设置为 24:6，完美横跨 A4
    fig, axes = plt.subplots(nrows=1, ncols=4, figsize=(24, 6), gridspec_kw={'wspace': 0.05})
    
    # 标题和列对应 (将原本的 Spatial View 换成了对比性更强的 STAGATE View)
    titles = ['Original H&E', 'RNA View', 'STAGATE View', 'Hisemble View']
    columns = [None, 'Cluster_RNA', 'Cluster_STAGATE', 'Cluster_Hisemble']
    
    for i, ax in enumerate(axes):
        if i == 0:
            # 图0：只画 H&E 底图，点变透明
            sc.pl.spatial(adata, img_key="hires", alpha=0, alpha_img=1.0, 
                          title=titles[i], show=False, ax=ax, frameon=False)
        else:
            # 图1/2/3：叠加聚类结果，底图半透明
            sc.pl.spatial(adata, color=columns[i], img_key="hires", alpha=0.8, alpha_img=0.3, 
                          title=titles[i], show=False, ax=ax, frameon=False)
        
        # 1. 隐藏默认的坐标与标签
        ax.set_xlabel('')
        ax.set_ylabel('')
        ax.set_xticks([])
        ax.set_yticks([])
        ax.title.set_fontsize(20)
        ax.title.set_fontweight('bold')
        
        # 2. 画出封闭式的黑边框
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_color('black')
            spine.set_linewidth(1.2)
            
        # 3. 处理图例：移除默认右侧图例，放入底部
        legend = ax.get_legend()
        if legend:
            handles = legend.legend_handles if hasattr(legend, 'legend_handles') else legend.legendHandles
            labels = [t.get_text() for t in legend.get_texts()]
            legend.remove() # 移除默认图例
            
            # 在底部中央重新生成图例，分 4 列，解决拥挤
            ax.legend(handles, labels, 
                      loc='upper center', 
                      bbox_to_anchor=(0.5, -0.05), # 置于图框底部外部
                      ncol=4, 
                      frameon=False, 
                      prop={'size': 14, 'weight': 'bold'})
            
            # 放大图例里的色标点
            try:
                for handle in handles:
                    handle.set_sizes([100])
            except:
                pass

    out_file = "Breast_Cancer_4Panels_A4.pdf"
    # bbox_inches='tight' 会确保底部的图例不会被裁剪出框外
    plt.savefig(out_file, dpi=300, format="pdf", bbox_inches='tight')
    plt.close()
    print(f"✅ 成功生成 A4 横屏合并大图：{out_file}\n")

if __name__ == "__main__":
    main()