import scanpy as sc
import pandas as pd
import scipy.io
import os
import matplotlib.pyplot as plt
import igraph as ig
import leidenalg
import numpy as np
from scRNA.src.utils import find_best_matrix, perform_leiden_clustering, remove_duplicates, build_knn_graph_chunked_cpu, normalize_sparse, sparsify_matrix
from sklearn.metrics.pairwise import rbf_kernel, euclidean_distances
from sklearn.metrics import adjusted_rand_score,adjusted_mutual_info_score,normalized_mutual_info_score, homogeneity_score
from scipy.spatial.distance import pdist, squareform
from sklearn.metrics import pairwise_distances
from scipy.sparse import csr_matrix, identity as sparse_identity
from sklearn.neighbors import NearestNeighbors

K_NEIGHBORS = 15
N_ITERATIONS = 20
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
os.environ['PYTHONHASHSEED'] = str(RANDOM_SEED)

adata = sc.read_h5ad("scRNA_lung.h5ad")
embedding_pca = adata.obsm['X_pca']
print(f"视图 1 (PCA) 准备就绪: {embedding_pca.shape}")
embedding_scvi = adata.obsm['X_scvi']
print(f"视图 2 (scVI) 准备就绪: {embedding_scvi.shape}")
true_labels = adata.obs.cell_type.to_numpy()
true_cell_types = adata.obs['cell_type'].nunique()

W_pca = build_knn_graph_chunked_cpu(embedding_pca, k_neighbors=15, metric='gaussian') 
W_scvi = build_knn_graph_chunked_cpu(embedding_scvi, k_neighbors=15, metric='gaussian') 
W_list = [W_pca, W_scvi]

def SNF(W_list: list, k_neighbors: int = 15, n_iterations: int = 20, random_seed=42) -> csr_matrix:
    num_views = len(W_list)
    n_samples = W_list[0].shape[0]
    P_list = [normalize_sparse(W) for W in W_list]
    k_retained = k_neighbors * 2
    for iter_num in range(n_iterations):
        print(f"  - 第 {iter_num + 1}/{n_iterations} 次迭代...")
        P_updated_list = []
        for i in range(num_views):
            sum_P_others = csr_matrix((n_samples, n_samples), dtype=np.float32)
            for j in range(num_views):
                if i != j:
                    sum_P_others += P_list[j]
            avg_P_others = sum_P_others / (num_views - 1)
            W_sparse = W_list[i]
            P_updated = W_sparse @ avg_P_others @ W_sparse.T 
            P_updated_sparsified = sparsify_matrix(P_updated, k_retained, random_seed=random_seed)
            P_updated = normalize_sparse(P_updated_sparsified)
            P_updated_list.append(P_updated)
        P_list = P_updated_list
    final_P = csr_matrix((n_samples, n_samples), dtype=np.float32)
    for P in P_list:
        final_P += P
    final_P /= num_views
    final_affinity = (final_P + final_P.T) / 2
    return final_affinity

fused_network = SNF(W_list, k_neighbors=K_NEIGHBORS, n_iterations=N_ITERATIONS, random_seed=RANDOM_SEED)
sources, targets = fused_network.nonzero()
weights = fused_network[sources, targets].A1
net = ig.Graph(list(zip(sources, targets)), directed=False)
net.es['weight'] = weights
clusters = find_best_matrix(matrix=net, true_cell_types=true_cell_types, seed=RANDOM_SEED)
fused_network = fused_network.astype(np.float32)
adata.obsp['connectivities'] = fused_network
distances = adata.obsp['connectivities'].copy()
distances.data = 1.0 - distances.data
distances.eliminate_zeros() # 移除那些 similarity=1.0 导致的 0
adata.obsp['distances'] = distances

adata.uns['neighbors'] = {}
adata.uns['neighbors']['params'] = {'method': 'custom', 'custom_graph': True}
adata.uns['neighbors']['connectivities_key'] = 'connectivities' 
adata.uns['neighbors']['distances_key'] = 'distances'  

sc.tl.umap(adata, random_state=RANDOM_SEED)
if len(clusters) != adata.n_obs:
    raise ValueError(f"聚类列表的长度 ({len(clusters)}) "
                        f"与 adata.n_obs ({adata.n_obs}) 不匹配")
adata.obs['Hisemble'] = clusters
adata.obs['Hisemble'] = adata.obs['Hisemble'].astype('category')

sc.pl.umap(adata, color=['cell_type'], show=False, color_map='viridis')
plt.savefig('umap_cell_type(Lung_Hisemble).pdf', dpi=300, format="pdf", bbox_inches='tight', transparent=True)
plt.close() # 关闭图像，防止在循环中占用过多内存

sc.pl.umap(adata, color=['Hisemble'], show=False, color_map='viridis')
plt.savefig('umap_Hisemble(Lung_Hisemble).pdf', dpi=300, format="pdf", bbox_inches='tight', transparent=True)
plt.close() # 关闭图像，防止在循环中占用过多内存

ARI = adjusted_rand_score(true_labels, clusters)
AMI = adjusted_mutual_info_score(true_labels, clusters)
NMI = normalized_mutual_info_score(true_labels, clusters)
HOM = homogeneity_score(true_labels, clusters)

result_data = {
    'k_neighbors': [K_NEIGHBORS],
    'n_iterations': [N_ITERATIONS],
    'ARI': [ARI],
    'AMI': [AMI],
    'NMI': [NMI],
    'HOM': [HOM]
}
result_df = pd.DataFrame(result_data)

result_df.to_csv('metrics_lung.csv', index=False)

adata.write_h5ad("lung_hisemble_results.h5ad")