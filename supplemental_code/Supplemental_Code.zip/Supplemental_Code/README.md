# Hisemble Supplemental Code — revision snapshot, 2026-10-04

This archive contains the custom code needed to reproduce the computational
analyses reported in the manuscript and revision: the tested Hisemble core,
portable environment specifications, preprocessing and representation workflows,
benchmarking and downstream-analysis workflows, reviewer-requested analyses, and
compact machine-readable results.

Start with `Reproduction_Tutorial.md` for Docker installation, automated checks, a
complete synthetic example, an own-data command, and revision-analysis commands.

Pure figure styling, panel assembly, and export scripts are outside this archive.
The reported numerical analyses do not depend on those presentation-only sources.
Final figures and their legends are submitted separately as manuscript and
Supplemental Material files.

## Contents

- `revision_core/`: Hisemble core, tests, pinned Docker/Conda/pip specifications,
  reviewer analyses, and compact CSV/JSON results.
- `manuscript_templates/historical/`: preserved preprocessing, representation,
  benchmarking, scRNA, spatial, and downstream computational workflows.
- `manuscript_templates/local/`: retained executable scRNA and spatial input/preparation
  workflows that are not presentation-only.
- `SOURCE_MANIFEST.csv`: source provenance, hashes, configuration keys, and status.
- `ANALYSIS_MAP.md`: computational question-to-entry-point map.
- `INPUTS_AND_ENVIRONMENTS.md`: external inputs and environment boundaries.
- `DEPENDENCY_IMPORTS.csv`: historical Python import inventory.

## Configure historical paths

Copy `config.example.json`, replace every `/path/to/...` value, and generate
configured working copies without changing the archived templates:

```bash
python materialize.py --config /path/to/config.json --output /path/to/new-workdir
```

Input data, raw sequencing files, fonts, third-party repositories, credentials,
caches, and local configuration files are excluded. The tested core environment
accepts precomputed embeddings; upstream encoders retain their own dependencies.
See `INPUTS_AND_ENVIRONMENTS.md` before running historical workflows.

This is a self-contained journal revision snapshot. It does not require a matching GitHub release. See `VERSION_RELATIONSHIP.md` for compatibility and provenance.
