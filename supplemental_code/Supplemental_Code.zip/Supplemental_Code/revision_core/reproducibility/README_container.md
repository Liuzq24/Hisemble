Start with the current `Reproduction_Tutorial.md` (archive root or GitHub root).

# Hisemble core reproducibility environment

Reviewers starting from the journal archive should first read
`../../Reproduction_Tutorial.md` at the Supplemental Code root. It includes unpacking,
building, a complete synthetic run, own-data usage, and revision-analysis commands.

This environment reproduces the **Hisemble fusion and clustering core** from
precomputed cell embeddings. It intentionally does not bundle training
environments for scBasset, SnapATAC2, scVI, or other upstream encoders. Those
tools have separate GPU and platform requirements, whereas Hisemble only needs
their cell-by-feature embeddings.

## Docker

Build from the root of the repository:

```bash
docker build -f reproducibility/Dockerfile -t hisemble:reproduce .
```

Open a shell with the current directory mounted at `/work`:

```bash
docker run --rm -it -v "$PWD:/work" hisemble:reproduce
```

The numerical-library thread count defaults to one for reproducible resource
benchmarks. Users may override `OMP_NUM_THREADS`, `OPENBLAS_NUM_THREADS`,
`MKL_NUM_THREADS`, and `NUMEXPR_NUM_THREADS` when throughput is more important
than strict benchmark comparability.

Run the input-validation unit tests inside the image:

```bash
docker run --rm hisemble:reproduce \
  python /opt/hisemble/tests/test_hisemble_io.py
```

Run the core view-order invariance tests:

```bash
docker run --rm hisemble:reproduce \
  python /opt/hisemble/tests/test_hisemble_core.py
```

Run the package API and direct AnnData integration test:

```bash
docker run --rm hisemble:reproduce \
  python /opt/hisemble/tests/test_hisemble_api.py
```

The revision-stage build and test record is documented in `VALIDATION.md`.

## Conda

```bash
conda env create -f reproducibility/environment-core.yml
conda activate hisemble-core
```

## Input and output safeguards

`hisemble/io.py` provides validated input handling through
`validate_embeddings`, including shape, finite-value, cell-order, degeneracy,
and robust row-norm outlier checks. The main `run_hisemble` API reads input
representations from `AnnData.obsm` and writes its graph and labels back to the
same AnnData object for Scanpy workflows.

Hisemble produces a weighted cell-cell consensus graph. It does not silently
remove cells, impute upstream embeddings, or claim to produce a new Euclidean
joint embedding.
