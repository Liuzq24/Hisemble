# Computational analysis entry points

| Reported analysis | Entry point(s) | Principal output |
|---|---|---|
| scATAC Hisemble benchmark | `manuscript_templates/historical/workflows/scatac/hisemble/run_Hisemble.py` | clustered AnnData and benchmark metrics |
| LSI ablation | `manuscript_templates/historical/workflows/scatac/hisemble/Hisemble_ablation_lsi.py` | full/no-LSI metrics |
| Neighborhood sensitivity | `manuscript_templates/historical/workflows/scatac/hisemble/Hisemble_K_Sensitive.py` | metrics across k |
| Convergence | `manuscript_templates/historical/workflows/scatac/hisemble/Hisemble_convergence.py` | iteration-wise convergence records |
| SC3 and CHAI baselines | `manuscript_templates/historical/workflows/scatac/baselines/` | baseline metrics |
| Scaling/downsampling | `manuscript_templates/historical/workflows/scatac/downsampling/` | runtime, memory, and clustering metrics |
| scBasset, SnapATAC2, and LSI representations | `manuscript_templates/historical/workflows/scatac/representations/` | precomputed cell embeddings |
| scATAC preprocessing | `manuscript_templates/historical/workflows/scatac/preprocess/` | processed AnnData inputs |
| scRNA benchmark | `manuscript_templates/historical/workflows/scrna/` and `manuscript_templates/local/scRNA/src/run_*.py` | clustering metrics and labels |
| Spatial benchmark | `manuscript_templates/historical/workflows/spatial/run_GraphST.py` and `stagate_noplot.py` | clustering metrics and labels |
| Peak-to-gene downstream analysis | `manuscript_templates/historical/workflows/downstream/peakbed2gene/peakbed2gene.py` | peak-to-gene result table |
| Reviewer LSI complementarity | `manuscript_templates/historical/workflows/scatac/hisemble/Hisemble_ablation_lsi.py` and `revision_core/supplemental_code/reviewer_analyses/reviewer_lsi_neighbor_analysis.py` | full/no-LSI metrics and neighborhood summaries |
| Reviewer component ablation/scaling | `revision_core/supplemental_code/reviewer_analyses/component_ablation.py` and runner scripts | CSV/JSON measurements |
| Reviewer seed stability | `revision_core/supplemental_code/reviewer_analyses/reviewer_seed_stability.py` | 80 per-seed ARI/NMI records on eight datasets |
| Reviewer degraded-view robustness | `revision_core/supplemental_code/reviewer_analyses/reviewer_degraded_view.py` | 66-run result table |

Pure plotting and panel-layout scripts are not included. Figures and legends are
provided separately in the manuscript and Supplemental Material.

| Reviewer graph-based lineage analysis | `revision_core/supplemental_code/reviewer_analyses/lineage_trajectory_analysis.py` | six-candidate DPT summary, per-cell pseudotime, ten-root sensitivity |
