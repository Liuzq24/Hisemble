# Inputs and environments

## Tested revision core

Use `revision_core/reproducibility/README_container.md`, `VALIDATION.md`, and the
pinned Docker/Conda specifications. The core accepts precomputed embeddings. Its
recorded tests do not validate all historical scripts or upstream encoders.

## Historical scATAC workflows

`DATA_ROOT` follows the original layout:

```
ADATA/<dataset>_scBasset.pkl
ADATA/<dataset>_snap.pkl
lsi_results/ADATA/<dataset>_lsi.pkl
0.01_h5ad/<dataset>_processed.h5ad
```

The pickles hold AnnData objects with `obsm['projection']`, `obsm['X_spectral']`,
and `obsm['X_lsi']`, respectively. See each script for the expected annotation field
and dataset list. Some historical visualization scripts instead expect LSI under
`ADATA/`; provide the appropriate input location for the selected variant. Do not
assume that all variants use interchangeable filenames. `RESULTS_ROOT` holds
`SNF_final/`, baseline-specific folders, and `downsampling/` outputs, which downstream
scripts also read. Preprocessing scripts take h5ad/FASTA manifests; genome assemblies
must match each dataset. Reference FASTA files are supplied under `GENOME_ROOT`.

These scripts import additional packages such as Scanpy, seaborn, TensorFlow,
SnapATAC2 and scBasset. Baseline dependencies are recorded in `DEPENDENCY_IMPORTS.csv`.
Historical versions and hardware-specific encoder environments are not yet locked.
Do not install every imported package into the tested core environment as one stack.

## scRNA

The server candidate reads `Tabula_Sapiens/TS_<tissue>_30k_processed.h5ad` relative
to its launch directory and writes `results/Hisemble_RNA/`. It accepts `--tissues`;
its default list is defined in the script. Local pancreas and other tissue scripts
use different relative input names and helper imports. The upstream preprocessing/scVI environment remains to be confirmed.

## Spatial omics

`SPATIAL_ROOT` contains the processed MISAR-seq sections, including
`E11_0-S1_expr_preprocessed.h5ad`, `E13_5-S1_expr_preprocessed.h5ad`,
`E15_5-S1_expr_preprocessed.h5ad`, and `E18_5-S1_expr_preprocessed.h5ad` for the
GraphST RNA candidate. Inputs need the spatial coordinates and annotation fields
accessed in that script. GraphST/PyTorch and the alternative STAGATE workflows
need separate upstream environments. Their accelerator use differs from the
CPU-only Hisemble core benchmark. No exact historical versions are invented here.

## Downstream analyses

DAP scripts read the chosen Hisemble result h5ad, peak/count data, and marker tables.
`RAW_BRAIN_ROOT` and `RAW_ATAC_ROOT` configure raw matrices; `DOWNSTREAM_ROOT` configures
historical downstream working data. The peak-to-gene script expects
`ANNOTATION_ROOT/gencode.vM25.annotation.gtf` and a BED file such as
`cluster_0_GREAT.bed`. This filename is taken directly from the source; no different
annotation version is substituted. External GREAT/enrichment result tables remain required inputs where cited.

## Presentation files

Pure plotting, panel-layout, typography, and figure-export code is not part of the
Supplemental Code archive. Numerical result tables produced by the analyses are
reported in the manuscript, Supplemental Tables, or the compact reviewer-result
directories.

## Numerical lineage analysis

The revised image additionally installs `requirements-trajectory.txt`, including Scanpy 1.9.8, matching the analysis server. Six saved Hisemble result AnnData files are required, as listed in the reviewer tutorial. Only DPT, stage statistics and root sensitivity are computed; no figure rendering is required.
