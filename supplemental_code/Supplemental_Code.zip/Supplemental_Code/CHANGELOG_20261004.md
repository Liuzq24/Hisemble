# Changes since submission candidate 20261003

- Eight complete datasets and 80 seed runs; manuscript-aligned defaults replace obsolete default dataset names.
- Component results now use full Mouse Cortex (9,190 cells), FCA Intestine and MCA Cerebellum. No 3,000-cell Mouse Cortex subset is bundled.
- All five FCA screening candidates retained.
- Incomplete Intestine dense-variant measurements explicitly marked stopped for budget, without fabricated accuracy or completed peak memory.
- Degraded-view reference updated to three manuscript datasets and 66 runs.
- Numerical-only trajectory analysis, all six candidate results and ten-root sensitivity added. No UMAP or drawing is performed by that entry point.
- Parallel seed entry point added, with the original numerical functions preserved.
- Installation/reproduction tutorial updated; separate Scanpy/DPT requirements added and Docker validated.
- Independent snapshot version and additive GitHub integration scope documented. Existing package algorithms and APIs are unchanged from the prior submission core.
- No standalone figure scripts, figure binaries, raw sequencing data or input embeddings included.
