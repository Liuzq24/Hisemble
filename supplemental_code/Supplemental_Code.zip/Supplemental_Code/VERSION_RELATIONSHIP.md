# Supplemental snapshot and GitHub

This journal snapshot is independently versioned as 20261004. It does not modify the public repository or any existing installation. It includes additional reviewer analyses, updated reference results, portable entry points, and an optional DPT dependency stack.

The Hisemble package files, setup.py, original tests, and existing example programs are byte-identical to the 20261003 submission core. Package behavior has not been changed by this update. The main computational files (`api.py`, `core.py`, `graph.py`, `cluster.py`) also match the available GitHub checkout at commit affe79441ceccf236a0b971fccc170ec727183c5. The checkout includes additional IO helpers absent from the journal snapshot. This revision does not add export helpers and uses the existing direct AnnData workflow. If reviewer analyses are added to GitHub, preserve its current `io.py`, `__init__.py`, and tests rather than overwriting them with the submission files. The two portable examples are new submission-only files. Compatibility is checked by tests and examples, not inferred from the snapshot date.

Suitable GitHub updates would add the reviewer analyses/results and tutorial/environment specifications without replacing public core algorithms or changing existing APIs. The companion GitHub update adds numerical analyses, reference results, examples, documentation and the validated Docker environment, while preserving existing public package interfaces.

Build the snapshot under its own Docker tag, `hisemble:reproduce`, to retain older local images. No container image is uploaded to a registry.

## Additive GitHub update scope

- Add/update only the numerical reviewer analyses and current reference tables under `supplemental_code/`.
- Add the two portable examples under `examples/` and the reviewer tutorial as documentation.
- Put the trajectory dependency file and a separately named reviewer Dockerfile under `reproducibility/`, preserving the existing Dockerfile and core environment.
- Retain public `hisemble/`, existing APIs, tests and user-facing workflows.
- Do not upload drawing programs, input embeddings, temporary files, or machine-specific paths.

The final repository update and upload are recorded in the local publication record. The local public-checkout tests passed (10/10) under the new environment.
